﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ActivityTwo.ViewModels;
using ActivityTwo.Models;

namespace ActivityTwo.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        /*Initial request for this*/

        public ActionResult Reports()
        {
            ReportController vm = new ReportController();

            //Retrieve a list of vendors so that it can be used to populate the dropdown on the View
            vm.Employee = getEmployee(0);
            //vm.SalFrom = getSalaryFrom(0);
            //vm.SalTo = getSalaryTo(0);
            //Default values for from and to
            //vm.salFrom = vm.SalFrom;
            //vm.salTo = vm.SalTo;
            return View(vm);
        }

  /*      public SelectList getSalaryFrom(int selected)
        {
            using (HardwareDBEntities1 db = new HardwareDBEntities1())
            {
                db.Configuration.ProxyCreationEnabled = false;

                //Create a SelectListItem for each Employee record in the DB
                //Value is set to the primary key of the record and Text is set to the Name of the employee
                var employee = db.lgsalary_history.Select(x => new SelectListItem
                {
                    Value = x.emp_num.ToString(),
                    Text =Convert.ToString( x.sal_from)
                }).ToList();

                //If selected pearameter has a value, configure the SelectList so that the apporiate item is preselected
                if (selected == 0)
                    return new SelectList(employee, "Value", "Text");
                else
                    return new SelectList(employee, "Value", "Text", selected);
            }
        }
        public SelectList getSalaryTo(int selected)
        {
            using (HardwareDBEntities1 db = new HardwareDBEntities1())
            {
                db.Configuration.ProxyCreationEnabled = false;

                //Create a SelectListItem for each Employee record in the DB
                //Value is set to the primary key of the record and Text is set to the Name of the employee
                var employee = db.lgsalary_history.Select(x => new SelectListItem
                {
                    Value = x.emp_num.ToString(),
                    Text = Convert.ToString(x.sal_end)
                }).ToList();

                //If selected pearameter has a value, configure the SelectList so that the apporiate item is preselected
                if (selected == 0)
                    return new SelectList(employee, "Value", "Text");
                else
                    return new SelectList(employee, "Value", "Text", selected);
            }
        }*/
        private SelectList getEmployee(int selected)
        {
            using (HardwareDBEntities1 db = new HardwareDBEntities1())
            {
                db.Configuration.ProxyCreationEnabled = false;

                //Create a SelectListItem for each Employee record in the DB
                //Value is set to the primary key of the record and Text is set to the Name of the employee
                var empl = db.lgemployees.Select(x => new SelectListItem
                {
                    Value = x.emp_num.ToString(),
                    Text = x.emp_fname +" "+ x.emp_lname
                }).ToList();

                //If selected pearameter has a value, configure the SelectList so that the apporiate item is preselected
                if (selected == 0)
                    return new SelectList(empl, "Value", "Text");
                else
                    return new SelectList(empl, "Value", "Text", selected);
            }
        }

        /*When values are selected for the criteria*/
        [HttpPost]
        public ActionResult Reports(ReportController vm)
        {
            using (HardwareDBEntities1 db = new HardwareDBEntities1())
            {
                db.Configuration.ProxyCreationEnabled = false;

                //Retrieve a list of vendors so that it can be used to populate the dropdown on the View
                //The ID of the currently selected item is passed through so that the returned list has that item preselected
                vm.Employee = getEmployee(vm.SelectedEmployeeID);

                //Get the full details of the selected vendor so that it can be displayed on the view
                vm.empl = db.lgemployees.Where(x => x.emp_num == vm.SelectedEmployeeID).FirstOrDefault();

                //Get all Salaries  that adheres to the entered criteria
                //For each of the results, load data into a new ReportRecord object
                var list = db.lgsalary_history.Include("lgemployee").Where(pp => pp.emp_num == vm.empl.emp_num).ToList().Select(rr => new ReportRecord
                {
                    To = rr.sal_end.ToString("dd-MMM-yyyy"),
                    Amount = Convert.ToDouble(rr.sal_amount),
                    From = rr.sal_from.ToString("dd-MMM-yyyy"),
                    Employees = db.lgemployees.Where(pp => pp.emp_num == rr.emp_num).Select(x => x.emp_fname + " " + x.emp_lname).FirstOrDefault(),
                   //db.lgsalary_history.Where(xx => xx.sal_amount >= rr.sal_amount).Select(yy => yy.emp_num).FirstOrDefault()
                    // SalaryOfEmployee =db.lgsalary_history.Where(xx => xx.emp_num == rr.emp_num).Select(dd => dd.sal_from + "-" + dd.sal_end).ToList(),
                    EmpID = Convert.ToInt32(rr.emp_num)
                });
                var listTwo = db.lgemployees.Join(db.lgsalary_history, u => u.emp_num, uir => uir.emp_num, (u, uir) => new { u, uir }).Where(s => s.u.emp_title == vm.empl.emp_title).ToList().Select(ee => new SalaryOfEmployee
                {
                    namesOfEmployees = ee.u.emp_fname + " " + ee.u.emp_lname,
                    balance = (double)ee.uir.sal_amount,
                });

                //Load the list of ReportRecords returned by the above query into a new list grouped by Shipment Method
                vm.results = list.GroupBy(g => g.From).ToList();

                //Load the list of ReportRecords returned by the above query into a new dictionary grouped by Employee
                //This will be used to generate the chart on the View through the MicroSoft Charts helper
                vm.chartData = listTwo.GroupBy(g => g.namesOfEmployees).ToDictionary(g => g.Key, g => g.Sum(v => v.balance));

                //Store the chartData dictionary in temporary data so that it can be accessed by the EmployeeOrdersChart action resonsible for generating the chart
                TempData["chartData"] = vm.chartData;
                TempData["records"] = list.ToList();
                TempData["employee"] = vm.empl;
                return View(vm);
            }

        }

        public ActionResult SalaryChart()
        {
            //Load the chartData from temporary memory
            var data = TempData["chartData"];

            //Return the EmployeeOrdersChart temporary view, pass through the required chartData
            return View(TempData["chartData"]);
        }
    }
}