﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ActivityTwo.Models;

namespace ActivityTwo.ViewModels
{
    public class ReportController
    {
        public IEnumerable<SelectListItem> Employee { get; set; }
        public int SelectedEmployeeID { get; set; }
        public DateTime salFrom { get; set; }
        public DateTime salTo { get; set; }

        //Fields for report data
        public lgemployee empl { get; set; }
        public List<IGrouping<string, ReportRecord>> results { get; set; }
        public Dictionary<string, double> chartData { get; set; }
    }

    public class ReportRecord
    {
        public string To { get; set; }
        public double Amount { get; set; }
        public string From { get; set; }
        public string Employees { get; set; }
        //public string SalaryOfEmployee { get; set; }
        public int EmpID { get; set; }
    }
    public class SalaryOfEmployee
    {
        public string namesOfEmployees { get; set; }
        public double balance { get; set; }
    }
}